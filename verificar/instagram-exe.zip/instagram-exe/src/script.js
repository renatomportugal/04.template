// you need *your own* access token and user ID if you want this to work!
var accessToken = '29531297.1677ed0.cd32b613aa7b4c8794d9bde3892b5801';
var userId = '29531297';

// http://instafeedjs.com
var userFeed = new Instafeed({
	target: 'profile',
	get: 'user',
	userId: userId,
	limit: 18,
	accessToken: accessToken,
	template: '<a href="{{link}}" target="_blank"><img src="{{image}}" alt="{{caption}}"/></a>'
});
userFeed.run();

var userInfo = new Instafeed({
	target: 'info',
	get: 'user',
	userId: userId,
	limit: 1,
	accessToken: accessToken,
	// Ran into some trouble because I'm not accessing the right URL for profile data
	template: '<h2><a href="http://instagram.com/{{model.user.username}}">{{model.user.username}}</a></h2><hr/><div class="info"><div class="avatar"><img src="{{model.user.profile_picture}}" alt="{{model.user.username}}"/></div><ul><li><strong>777</strong><span>posts</span></li><li><strong>704</strong><span>followers</span></li><li><strong>634</strong><span>following</span></li><li><button>Follow</button><button></button></ul><div class="desc"><p>{{model.user.full_name}}</p><p>ui • web dev • game art • lipstick • anime • codepen: <a href="http://codepen.io/gabriellewee" target="_blank">@gabriellewee</a> • dribbble: <a href="http://dribbble.com/gabriellewee" target="_blank">@gabriellewee</a> • ui developer <a href="http://instagram.com/levelstudios" target="_blank">@LevelStudios</a></p><p><a href="http://gabriellew.ee">gabriellew.ee</a></p></div></div>'
});
userInfo.run();

var homeFeed = new Instafeed({
	target: 'home',
	get: 'user',
	userId: userId,
	resolution: 'standard_resolution',
	limit: 18,
	accessToken: accessToken,
	template: '<figure><header><a class="avatar" href="http://instagram.com/{{model.caption.from.username}}"><img src="{{model.caption.from.profile_picture}}"/></a><a href="http://instagram.com/{{model.caption.from.username}}">{{model.caption.from.username}}</a></header><img src="{{image}}" alt="{{caption}}"/><figcaption><div><button>Like</button><button>Comment</button><button>Share</button></div><div><button>Bookmark</button></div><div class="likes">Liked by {{likes}} people</div><div class="caption"><a href="http://instagram.com/{{model.caption.from.username}}" target="_blank">{{model.caption.from.username}}</a> <span>{{caption}}</span></div><div class="view-all comment-{{comments}}"><a href="{{link}}" target="_blank">View <span>{{comments}}</span> comment</a></div><time class="stamp" data-time="{{model.caption.created_time}}"></time></figcaption></figure>'
});
homeFeed.run();

// https://momentjs.com
setTimeout(function(){
	var timeStamps = document.getElementsByClassName('stamp');
	for (var i = 0; i < timeStamps.length; i++) {
		var s = timeStamps[i];
		var t = s.getAttribute('data-time');
		s.innerHTML = moment(t, "X").startOf('day').fromNow();
	}
}, 500);